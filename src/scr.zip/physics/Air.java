package physics;

public class Air extends Fluid{

	protected Air(float density) {
		super(1.29f);
	}

}
